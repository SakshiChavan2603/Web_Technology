console.log('2'*23);
console.log(2*'23');
console.log(2+'23');
console.log('2'*'23');
console.log("2"*23);
console.log("2"*"23");
console.log(2*"23");
console.log('A'*23); //NaN