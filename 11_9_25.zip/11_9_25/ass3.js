// 3) Declare Array with String Data 
// 	display every element in uppercase format
//              (use prdefined methods of String)

let a = "sakshi";

console.log("After Upper case :"+a.toUpperCase());

let b = "SAKSHI"
console.log("After lower case :"+b.toLowerCase());
