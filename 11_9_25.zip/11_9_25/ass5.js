// 5) write a function that multiplies two numbers and returns the value

function mul(a,b){
    return a*b;
}
let a=10, b=20;
console.log("Multiplication of "+a+"*"+b+"="+mul(a,b));