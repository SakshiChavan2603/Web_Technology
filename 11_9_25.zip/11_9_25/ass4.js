// 4) write a function to add 3 numbers and print the values

function add(a,b,c){
    return a+b+c;
}
let a=1,b=2,c=3;
let addition = add(a,b,c);
console.log("Addition of "+a+"+"+b+"+"+c+"="+addition);